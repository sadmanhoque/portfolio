# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 11:51:44 2019

@author: sadman
"""

import tweepy
import json

consumer_key = ''
consumer_secret = ''
access_token = ''
access_token_secret = ''
# OAuth process, using the keys and tokens
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth)

trends1 = api.trends_place(1)
# converting dict to a list
data = trends1[0] 
# grab the trends
trends = data['trends']
# grab the name from each trend
names = [trend['name'] for trend in trends]

#prints list of all trending topics; NOT NECESSARY TO RUN
for x in range(len(names)):
    print(names[x])

#prints 3 tweets of the nth trend, where query=names[n]
max_tweets=4
query = names[5]
searched_tweets = [status._json for status in tweepy.Cursor(api.search,  q=query).items(max_tweets)]
json_strings = [json.dumps(json_obj) for json_obj in searched_tweets]  
output=json_strings[0]
t = json.loads(output)
tList= [t['text'] for text in t]
for x in range(max_tweets):
    print (tList[x])
    print ("************************************************")

