Sadman Hoque Sadi 		A00426020
Ashwin Sivaraman		A00426488
#######################################################################################
if [ -a out ]; then
	rm -rf out #removes folder out if exist
	fi
mkdir out
cd out
wget -nc http://lnx.cs.smu.ca/docker/Dockerfile  #Download file
wget -nc http://lnx.cs.smu.ca/docker/app.py      #Download file
x=$(date "+%d") #Gets day of the month
y=$(if [[ $((x % 2)) -eq 0 ]]; then echo "Today is an even day"; else echo "Today is an odd day"; fi)  #checks if even or odd
cat app.py | sed -r "s/Hello World/$y/g" > test.txt #Overwrite Hello world with even/odd statement and writes to new file test.txt
cat test.txt > app.py  #Overwrites app.py with test.txt content
docker build -t a_sivaraman_a2 . #Builds the docker image
for i in {1999..65535} #checks open ports
 	do
	docker run -d -p $i:80 a_sivaraman_a2 #runs docker image
	if [ $? == 0 ]; then
	break
	fi
	done
docker inspect a_sivaraman_a2 | grep '"IPAddress"' | head -n 1 #finds IP address
wget lnx.cs.smu.ca:$i > serv.html #saves webpage to serve.html
id=`docker ps | grep "a_sivaraman_a2" | awk '{print $1}' | head -1`  #retrieve container id for specific instance
if [ $? != 0 ]; then #check if error
	docker container stop "$id"  
	docker container rm "$id"
	echo ERROR
	exit 1
  	fi
docker container stop "$id"
docker container rm "$id"
exit 0

trap oops 1 2 3 6

opps()
{
  id=`docker ps | grep "sh_sadi_a2" | awk '{print $1}' | head -1`
  docker container stop "$id"
  docker container rm "$id"
  exit 1
}
