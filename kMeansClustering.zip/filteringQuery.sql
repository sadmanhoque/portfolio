use datamining;

SET SQL_SAFE_UPDATES = 0;
DELETE FROM salesfiltered where CUSTOMER_SK='1';

SET SQL_SAFE_UPDATES = 0;
alter table salesfiltered drop column CASHIER_NO;

select * from salesfiltered order by transaction_sk limit 50;

create table customercluster as
select CUSTOMER_SK, sum(ITEM_QTY), sum(SELLING_RETAIL_AMT), time_,
count(distinct ITEM_SK) as itemvariety, count(distinct TRANSACTION_SK) as no_visit
from salesfiltered
group by CUSTOMER_SK;

/*create table customercluster as
select customer_sk, sum(item_qty) as item_no, sum(selling_retail_amt) as total_bill, time_, CALENDER_DT,
count(distinct item_sk) as item_variety, count(distinct transaction_sk) as transaction_ 
from salesfiltered
group by customer_sk;*/

select * from customercluster
limit 100;

alter table customercluster
modify column time_ time;

/*alter table customercluster
modify column hour(time_) as time_;*/

create table customercluster2
select customer_sk, item_no, total_bill, hour(time_), calender_dt, item_variety, transaction_
from customercluster;

/*create table customerclusters3 as
add column sum(transaction_) as transaction_tot
group by customer_sk;*/