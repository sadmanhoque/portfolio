cust<-read.csv("customerClustersSecond.csv",header=T)
plot(cust)
summary(cust)
cust<- cust[,-1]
plot(cust)
View(cust)

km = kmeans(cust[1:nrow(cust),1:4],9 ,150)
km$size
km$centers
km$cluster

custClust=cbind(cust, km$cluster)
plot(custClust[,1:4], col=km$cluster)

library(ggplot2)
library(GGally)
install.packages("DMwR")
library(DMwR)

withinSSrange <- function(data,low,high,maxIter)
{
  withinss = array(0, dim=c(high-low+1));
  for(i in low:high)
  {
    withinss[i-low+1] <- kmeans(data, i, maxIter)$tot.withinss
  }
  withinss
}

plot(withinSSrange(cust[,1:4], 2, 15, 150))
summary(custClust)



