# -*- coding: utf-8 -*-
"""
Created on Fri Feb 15 16:36:47 2019

@author: sadma
"""
#ENTER THE COMPANY DOMAIN YOU WANT TO SEARCH FOR
companyDomain="a-1freeman.com"

import sys
import json
from pprint import pprint
# Import Elasticsearch package 
from elasticsearch import Elasticsearch 
# Connect to the elastic cluster
es=Elasticsearch([{'host':'localhost','port':9200}])
es

#reading txt file as json cause this works better somehow
with open('sample_companies.txt') as json_file:  
    data = json.load(json_file)


# loop through file to insert into elasticSearch index
# RUN THIS SECTION ONLY ONCE FOR A GIVEN DATASET, INDEXING TAKES A LONG TIME
i=1
for key in data:
    e1=data[key]
    res = es.index(index='megacorp',doc_type='employee',id=i,body=e1)
    i=i+1

# fetching the company information
coCountry=data["asiwi.com"]['country']
coIndustry=data["asiwi.com"]['industry']

# Multi-search query    
res= es.search(index='megacorp',doc_type='employee',body={
        'query': {
            'bool': { 
                'must': [    
                    {'match_phrase':{"country":coCountry}},
                    {'match_phrase':{"industry":coIndustry}}
                ]
            }
        }
    })
    
# prints out the result of search query
for hit in res['hits']['hits']:
    print (hit['_source']['name'] )
    print (hit['_score'])
    print ('**********************')
    
