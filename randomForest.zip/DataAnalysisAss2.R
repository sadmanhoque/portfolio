data = read.csv("carDataModded.csv")
View(data)
library(randomForest)
library(pROC)
x=data[,1:6]
y=data[,7]
View(y)
View(x)

rf=randomForest(x,y)
rfp=predict(rf,x)
rfpCM=table(rfp,y)
View(rfpCM)

sum(diag(rfpCM))/sum(rfpCM)
rfProb=predict(rf,x,type="prob")
multiclass.roc(data[,7],rfProb[,1])
plot(roc(data[,7],rfProb[,1]))
plot(roc(data[,7],rfProb[,2]))
plot(roc(data[,7],rfProb[,3]))
plot(roc(data[,7],rfProb[,4]))
write.csv(data, file="data.csv")
write.csv(rfProb, file="dataProb.csv")
data = read.csv("data.csv")
rfProb = read.csv("dataProb.csv")
plot(roc(data[,8],rfProb[,5]))
plot(roc(data[,9],rfProb[,6]))
plot(roc(data[,10],rfProb[,7]))
plot(roc(data[,11],rfProb[,8]))

install.packages("caret")
install.packages('e1071', dependencies=TRUE)
library(caret)

control <- trainControl(method="repeatedcv", number=10, repeats=3)
seed <- 5
metric <- "Accuracy"
set.seed(seed)
rf_default <- train(x,y, method="rf", metric=metric, trControl=control)

rf=randomForest(x,y,nodesize=10)
control <- trainControl(method="repeatedcv", number=10, repeats=3)
rf_default <- train(x,y, method="rf", metric=metric, trControl=control)
rf_default
